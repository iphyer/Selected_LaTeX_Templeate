cvclean
=======

Custom LaTeX class for semantic markup of academic CVs.

See my CV source file for details on usage.
